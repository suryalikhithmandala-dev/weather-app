This folder is intentionally empty in source control.

Run `npm run cap:add:android` (i.e. `npx cap add android`) from the project
root to generate the native Android project here. See the main README.md
for full step-by-step instructions.
