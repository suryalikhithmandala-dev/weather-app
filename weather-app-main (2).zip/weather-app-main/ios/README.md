This folder is intentionally empty in source control.

Run `npm run cap:add:ios` (i.e. `npx cap add ios`) from the project root,
on a Mac with Xcode installed, to generate the native iOS project here.
See the main README.md for full step-by-step instructions.
