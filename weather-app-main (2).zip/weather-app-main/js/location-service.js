/* ====================================================================
   SKYCAST — LOCATION SERVICE MODULE
   Wraps the free Open-Meteo Geocoding API for forward search and
   uses BigDataCloud's key-less reverse-geocoding endpoint for
   "Use My Location" support.
   Docs: https://open-meteo.com/en/docs/geocoding-api
   ==================================================================== */

const LocationService = (() => {
  const GEOCODE_ENDPOINT = "https://geocoding-api.open-meteo.com/v1/search";
  const REVERSE_ENDPOINT =
    "https://api.bigdatacloud.net/data/reverse-geocode-client";
  const REQUEST_TIMEOUT_MS = 10000;

  // ==================== POPULAR CITIES ====================
  const POPULAR_CITIES = [
    {
      name: "Darjeeling",
      country: "India",
      latitude: 27.041,
      longitude: 88.2663,
      admin1: "West Bengal",
    },
    {
      name: "London",
      country: "United Kingdom",
      latitude: 51.5074,
      longitude: -0.1278,
      admin1: "England",
    },
    {
      name: "Chicago",
      country: "United States",
      latitude: 41.8781,
      longitude: -87.6298,
      admin1: "Illinois",
    },
    {
      name: "Mumbai",
      country: "India",
      latitude: 19.076,
      longitude: 72.8777,
      admin1: "Maharashtra",
    },
    {
      name: "New York",
      country: "United States",
      latitude: 40.7128,
      longitude: -74.006,
      admin1: "New York",
    },
    {
      name: "Tokyo",
      country: "Japan",
      latitude: 35.6762,
      longitude: 139.6503,
      admin1: "Tokyo",
    },
    {
      name: "Paris",
      country: "France",
      latitude: 48.8566,
      longitude: 2.3522,
      admin1: "Île-de-France",
    },
    {
      name: "Dubai",
      country: "United Arab Emirates",
      latitude: 25.2048,
      longitude: 55.2708,
      admin1: "Dubai",
    },
  ];

  async function fetchWithTimeout(url, timeoutMs) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      return await fetch(url, { signal: controller.signal });
    } finally {
      clearTimeout(timer);
    }
  }

  // ==================== FORWARD SEARCH ====================
  async function searchLocations(query) {
    const trimmedQuery = query.trim();
    if (!trimmedQuery) {
      throw new Error("Please enter a city or location name to search.");
    }

    const params = new URLSearchParams({
      name: trimmedQuery,
      count: "8",
      language: "en",
      format: "json",
    });

    let response;
    try {
      response = await fetchWithTimeout(
        `${GEOCODE_ENDPOINT}?${params.toString()}`,
        REQUEST_TIMEOUT_MS,
      );
    } catch (error) {
      if (error.name === "AbortError") {
        throw new Error("The location search took too long. Please try again.");
      }
      throw new Error(
        "Could not reach the location search service. Please check your internet connection.",
      );
    }

    if (!response.ok) {
      throw new Error(
        `Location search failed (status ${response.status}). Please try again.`,
      );
    }

    const data = await response.json();
    const results = Array.isArray(data.results) ? data.results : [];

    return results.map(normalizeGeocodeResult);
  }

  function normalizeGeocodeResult(result) {
    return {
      name: result.name,
      country: result.country || "",
      countryCode: result.country_code || "",
      admin1: result.admin1 || "",
      latitude: result.latitude,
      longitude: result.longitude,
      timezone: result.timezone || "auto",
      population: result.population || null,
    };
  }

  // ==================== REVERSE GEOCODING (Use My Location) ====================
  async function reverseGeocode(latitude, longitude) {
    const params = new URLSearchParams({
      latitude: latitude.toFixed(4),
      longitude: longitude.toFixed(4),
      localityLanguage: "en",
    });

    try {
      const response = await fetchWithTimeout(
        `${REVERSE_ENDPOINT}?${params.toString()}`,
        REQUEST_TIMEOUT_MS,
      );
      if (!response.ok) throw new Error("reverse geocode failed");
      const data = await response.json();
      return {
        name:
          data.city ||
          data.locality ||
          data.principalSubdivision ||
          "Current Location",
        country: data.countryName || "",
        countryCode: data.countryCode || "",
        admin1: data.principalSubdivision || "",
        latitude,
        longitude,
      };
    } catch (error) {
      // Non-fatal: fall back to plain coordinates so weather can still load.
      return {
        name: "Current Location",
        country: "",
        countryCode: "",
        admin1: "",
        latitude,
        longitude,
      };
    }
  }

  // ==================== GEOLOCATION PERMISSION WRAPPER ====================
  function getCurrentPosition() {
    return new Promise((resolve, reject) => {
      if (!("geolocation" in navigator)) {
        reject(
          new Error("Geolocation is not supported on this device or browser."),
        );
        return;
      }
      navigator.geolocation.getCurrentPosition(
        (position) => resolve(position.coords),
        (error) => {
          if (error.code === error.PERMISSION_DENIED) {
            reject(
              new Error(
                "Location permission was denied. Please allow location access or search manually.",
              ),
            );
          } else if (error.code === error.TIMEOUT) {
            reject(
              new Error(
                "Locating you took too long. Please try again or search manually.",
              ),
            );
          } else {
            reject(
              new Error(
                "Could not determine your location. Please search manually.",
              ),
            );
          }
        },
        { enableHighAccuracy: true, timeout: 12000, maximumAge: 300000 },
      );
    });
  }

  return {
    POPULAR_CITIES,
    searchLocations,
    reverseGeocode,
    getCurrentPosition,
  };
})();
