/* ====================================================================
   SKYCAST — MAIN APPLICATION SCRIPT
   ==================================================================== */

(() => {
  "use strict";

  // ==================== DOM ELEMENT REFERENCES ====================
  const dom = {
    navbar: document.getElementById("navbar"),
    navLinks: document.getElementById("navLinks"),
    navBurger: document.getElementById("navBurger"),
    themeToggle: document.getElementById("themeToggle"),

    heroGreeting: document.getElementById("heroGreeting"),

    searchForm: document.getElementById("searchForm"),
    searchInput: document.getElementById("searchInput"),
    searchClear: document.getElementById("searchClear"),
    searchBtn: document.getElementById("searchBtn"),
    searchError: document.getElementById("searchError"),
    searchSuggestions: document.getElementById("searchSuggestions"),

    useLocationBtn: document.getElementById("useLocationBtn"),
    popularCitiesBtn: document.getElementById("popularCitiesBtn"),
    popularCitiesPanel: document.getElementById("popularCitiesPanel"),

    bgImageA: document.getElementById("bgImageA"),
    bgImageB: document.getElementById("bgImageB"),

    weatherLocation: document.getElementById("weatherLocation"),
    weatherRegion: document.getElementById("weatherRegion"),
    weatherDateTime: document.getElementById("weatherDateTime"),
    weatherTemp: document.getElementById("weatherTemp"),
    weatherIcon: document.getElementById("weatherIcon"),
    weatherDesc: document.getElementById("weatherDesc"),
    weatherQuote: document.getElementById("weatherQuote"),

    unitToggle: document.getElementById("unitToggle"),
    favoriteBtn: document.getElementById("favoriteBtn"),

    metricFeelsLike: document.getElementById("metricFeelsLike"),
    metricHumidity: document.getElementById("metricHumidity"),
    metricWind: document.getElementById("metricWind"),
    metricWindDir: document.getElementById("metricWindDir"),
    metricPressure: document.getElementById("metricPressure"),
    compassNeedle: document.getElementById("compassNeedle"),

    alertsBody: document.getElementById("alertsBody"),
    alertCount: document.getElementById("alertCount"),

    tipText: document.getElementById("tipText"),

    forecastList: document.getElementById("forecastList"),

    exploreSaved: document.getElementById("exploreSaved"),
    exploreAlerts: document.getElementById("exploreAlerts"),
    savedPanel: document.getElementById("savedPanel"),
    savedList: document.getElementById("savedList"),
    savedEmpty: document.getElementById("savedEmpty"),

    liveStatus: document.getElementById("liveStatus"),
  };

  // ==================== APPLICATION STATE ====================
  const state = {
    currentLocation: null, // { name, country, admin1, latitude, longitude }
    currentWeather: null, // normalized payload from WeatherAPI
    isCelsius: true,
    theme: "dark",
    searchDebounceTimer: null,
    mapReady: false,
  };

  const DEFAULT_LOCATION = LocationService.POPULAR_CITIES[0]; // Darjeeling

  // ==================== WEATHER ICON SET (inline SVG) ====================
  const WeatherIcons = {
    clear: (isDay) =>
      isDay
        ? `<svg viewBox="0 0 24 24" fill="none" stroke="#ecce97" stroke-width="1.6"><circle cx="12" cy="12" r="4.4"/><path d="M12 2.5v2.4M12 19.1v2.4M4.2 4.2l1.7 1.7M18.1 18.1l1.7 1.7M2.5 12h2.4M19.1 12h2.4M4.2 19.8l1.7-1.7M18.1 5.9l1.7-1.7"/></svg>`
        : `<svg viewBox="0 0 24 24" fill="#e7ecf5"><path d="M20 14.6A8 8 0 0 1 9.4 4a8.4 8.4 0 1 0 10.6 10.6z"/></svg>`,
    cloudy: () =>
      `<svg viewBox="0 0 24 24" fill="none" stroke="#eef1f6" stroke-width="1.6"><circle cx="8.5" cy="9.5" r="3.4" fill="#ecce97" stroke="none"/><path d="M7 18.5a4 4 0 0 1-.5-7.97 5 5 0 0 1 9.62-1.9A4.5 4.5 0 0 1 17 18.5H7z" fill="#eef1f6" stroke="none"/></svg>`,
    overcast: () =>
      `<svg viewBox="0 0 24 24" fill="none"><path d="M6 18a4 4 0 0 1-.6-7.96A5 5 0 0 1 15 8.6 4.3 4.3 0 0 1 16.5 18H6z" fill="#c8cfda"/><path d="M8.5 18.6a3.4 3.4 0 0 1-.4-6.77A4.3 4.3 0 0 1 16.3 10a3.7 3.7 0 0 1 1.3 8.6H8.5z" fill="#dfe4ec" opacity="0.9"/></svg>`,
    fog: () =>
      `<svg viewBox="0 0 24 24" fill="none" stroke="#c9d2dc" stroke-width="1.8" stroke-linecap="round"><path d="M5 8.5h9M4 12h16M6 15.5h12M8 19h8"/></svg>`,
    rain: () =>
      `<svg viewBox="0 0 24 24" fill="none"><path d="M6 14a4 4 0 0 1-.5-7.96A5 5 0 0 1 15 4.6 4.3 4.3 0 0 1 16.5 14H6z" fill="#d7dde6"/><g stroke="#8fc7e8" stroke-width="1.6" stroke-linecap="round"><path d="M8 17l-1.3 3M12 17l-1.3 3M16 17l-1.3 3"/></g></svg>`,
    snow: () =>
      `<svg viewBox="0 0 24 24" fill="none"><path d="M6 13a4 4 0 0 1-.5-7.96A5 5 0 0 1 15 3.6 4.3 4.3 0 0 1 16.5 13H6z" fill="#e4e9f0"/><g stroke="#cfe6f7" stroke-width="1.5" stroke-linecap="round"><path d="M8 17v4M6 19h4M13 17v4M11 19h4M17 17v4M15 19h4"/></g></svg>`,
    thunder: () =>
      `<svg viewBox="0 0 24 24" fill="none"><path d="M6 12.5a4 4 0 0 1-.5-7.96A5 5 0 0 1 15 2.6 4.3 4.3 0 0 1 16.5 12.5H6z" fill="#a9b3c2"/><path d="M12.5 12l-3 5h2.4l-1.2 4 4.3-6h-2.4l1-3z" fill="#ecce97"/></svg>`,
  };

  function getWeatherIconMarkup(group, isDay) {
    const renderer = WeatherIcons[group] || WeatherIcons.clear;
    return renderer(isDay !== false);
  }

  // Small icon set reused for the 5-day forecast cards (always "day" style).
  function getForecastIconMarkup(group) {
    return getWeatherIconMarkup(group, true);
  }

  // ==================== GREETING (TIME-BASED) ====================
  function updateGreeting() {
    const hour = new Date().getHours();
    let greeting = "Good Evening";
    if (hour >= 5 && hour < 12) greeting = "Good Morning";
    else if (hour >= 12 && hour < 17) greeting = "Good Afternoon";
    else if (hour >= 17 && hour < 21) greeting = "Good Evening";
    else greeting = "Good Night";
    dom.heroGreeting.textContent = greeting;
  }

  // ==================== THEME TOGGLE ====================
  function applyTheme(theme) {
    state.theme = theme;
    document.documentElement.setAttribute("data-theme", theme);
    dom.themeToggle.setAttribute(
      "aria-pressed",
      theme === "light" ? "true" : "false",
    );
    try {
      localStorage.setItem("skycast.theme", theme);
    } catch (e) {
      /* ignore */
    }
  }

  function initTheme() {
    let saved = null;
    try {
      saved = localStorage.getItem("skycast.theme");
    } catch (e) {
      /* ignore */
    }
    if (saved === "light" || saved === "dark") {
      applyTheme(saved);
      return;
    }
    const prefersLight =
      window.matchMedia &&
      window.matchMedia("(prefers-color-scheme: light)").matches;
    applyTheme(prefersLight ? "light" : "dark");
  }

  dom.themeToggle.addEventListener("click", () => {
    applyTheme(state.theme === "dark" ? "light" : "dark");
  });

  // ==================== NAVIGATION (mobile menu + active link) ====================
  dom.navBurger.addEventListener("click", () => {
    const isOpen = dom.navLinks.classList.toggle("is-open");
    dom.navBurger.classList.toggle("is-open", isOpen);
    dom.navBurger.setAttribute("aria-expanded", String(isOpen));
  });

  dom.navLinks.querySelectorAll(".nav-link").forEach((link) => {
    link.addEventListener("click", () => {
      dom.navLinks.classList.remove("is-open");
      dom.navBurger.classList.remove("is-open");
      dom.navBurger.setAttribute("aria-expanded", "false");
      dom.navLinks
        .querySelectorAll(".nav-link")
        .forEach((l) => l.classList.remove("active"));
      link.classList.add("active");
    });
  });

  const sectionObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        const id = entry.target.id;
        dom.navLinks.querySelectorAll(".nav-link").forEach((link) => {
          link.classList.toggle("active", link.dataset.section === id);
        });
      });
    },
    { rootMargin: "-40% 0px -50% 0px" },
  );
  ["top", "forecast", "map", "about"].forEach((id) => {
    const el = document.getElementById(id);
    if (el) sectionObserver.observe(el);
  });

  // ==================== BACKGROUND IMAGE FUNCTIONS ====================
  let bgToggle = false; // alternates between layer A and B for crossfade

  function setBackgroundGradient(colors) {
    document.getElementById("bgLayer").style.background =
      `linear-gradient(160deg, ${colors[0]}, ${colors[1]})`;
    dom.bgImageA.classList.remove("is-visible");
    dom.bgImageB.classList.remove("is-visible");
  }

  function setBackgroundPhoto(url) {
    const incoming = bgToggle ? dom.bgImageB : dom.bgImageA;
    const outgoing = bgToggle ? dom.bgImageA : dom.bgImageB;

    const preload = new Image();
    preload.onload = () => {
      incoming.style.backgroundImage = `url("${url}")`;
      incoming.classList.add("is-visible");
      outgoing.classList.remove("is-visible");
      bgToggle = !bgToggle;
    };
    preload.onerror = () => {
      // Image failed after all — silently keep whatever background is showing.
    };
    preload.src = url;
  }

  async function updateBackgroundForLocation(location, weatherGroup) {
    try {
      const result = await ImageService.resolveLocationBackground({
        cityName: location.name,
        admin1: location.admin1,
        country: location.country,
        weatherGroup,
      });
      if (result.type === "photo") {
        setBackgroundPhoto(result.url);
      } else {
        setBackgroundGradient(result.colors);
      }
    } catch (error) {
      setBackgroundGradient(ImageService.WEATHER_GRADIENTS.default);
    }
  }

  // ==================== UNIT CONVERSION DISPLAY HELPERS ====================
  function formatTemp(celsiusValue) {
    if (
      celsiusValue === null ||
      celsiusValue === undefined ||
      Number.isNaN(celsiusValue)
    )
      return "--°";
    const value = state.isCelsius
      ? celsiusValue
      : WeatherAPI.celsiusToFahrenheit(celsiusValue);
    return `${Math.round(value)}°${state.isCelsius ? "C" : "F"}`;
  }

  function formatWind(kmhValue) {
    if (kmhValue === null || kmhValue === undefined) return "--";
    return state.isCelsius
      ? `${Math.round(kmhValue)} km/h`
      : `${Math.round(WeatherAPI.kmhToMph(kmhValue))} mph`;
  }

  // ==================== WEATHER CARD RENDERING ====================
  function formatDateTime(timezone) {
    try {
      const now = new Date();
      const formatter = new Intl.DateTimeFormat("en-US", {
        weekday: "short",
        day: "numeric",
        month: "short",
        year: "numeric",
        hour: "numeric",
        minute: "2-digit",
        timeZone: timezone || undefined,
      });
      return formatter.format(now);
    } catch (error) {
      return new Date().toLocaleString();
    }
  }

  const ATMOSPHERIC_QUOTES = {
    clear: "Clear skies, open mind.",
    cloudy: "Cool breeze, clear thoughts.",
    overcast: "Grey skies never last.",
    fog: "Slow down, the world is soft today.",
    rain: "Let the rain wash the noise away.",
    snow: "Every flake, a quiet moment.",
    thunder: "Nature's drumline is playing tonight.",
  };

  function renderWeatherCard(location, weather) {
    dom.weatherLocation.textContent = location.name;
    const regionParts = [location.admin1, location.country].filter(Boolean);
    dom.weatherRegion.textContent = regionParts.join(", ") || "\u00A0";
    dom.weatherDateTime.textContent = formatDateTime(weather.timezone);

    dom.weatherTemp.textContent = formatTemp(weather.current.temperature);
    dom.weatherDesc.textContent = weather.current.weatherLabel;
    dom.weatherIcon.innerHTML = getWeatherIconMarkup(
      weather.current.weatherGroup,
      weather.current.isDay,
    );
    dom.weatherQuote.textContent = `"${ATMOSPHERIC_QUOTES[weather.current.weatherGroup] || "Wherever you go, the sky follows."}"`;

    dom.metricFeelsLike.textContent = formatTemp(weather.current.feelsLike);
    dom.metricHumidity.textContent = `${Math.round(weather.current.humidity)}%`;
    dom.metricWind.textContent = formatWind(weather.current.windSpeed);
    dom.metricWindDir.textContent = weather.current.windDirectionLabel;
    dom.metricPressure.textContent = `${Math.round(weather.current.pressure)} hPa`;
    dom.compassNeedle.setAttribute(
      "transform",
      `rotate(${weather.current.windDirectionDegrees} 12 12)`,
    );

    dom.favoriteBtn.setAttribute(
      "aria-pressed",
      String(Favorites.isSaved(location)),
    );

    document.title = `${Math.round(weather.current.temperature)}°${state.isCelsius ? "C" : "F"} in ${location.name} — SkyCast`;
  }

  // ==================== FORECAST RENDERING ====================
  const DAY_NAMES = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

  function renderForecast(forecastDays) {
    // Skip today (index 0) so the strip shows the *upcoming* 5 days, matching the reference.
    const upcoming = forecastDays.slice(1, 6);
    dom.forecastList.innerHTML = upcoming
      .map((day) => {
        const dateObj = new Date(`${day.date}T00:00:00`);
        const dayName = DAY_NAMES[dateObj.getDay()];
        const dateLabel = dateObj.toLocaleDateString("en-US", {
          day: "numeric",
          month: "short",
        });
        return `
          <div class="forecast-card">
            <div class="forecast-day">${dayName}</div>
            <div class="forecast-date">${dateLabel}</div>
            <div class="forecast-icon">${getForecastIconMarkup(day.group)}</div>
            <div class="forecast-temps">${formatTemp(day.tempMax)} <span class="temp-min">/ ${formatTemp(day.tempMin)}</span></div>
            <div class="forecast-desc">${day.label}</div>
          </div>`;
      })
      .join("");
  }

  // ==================== WEATHER ALERTS (derived from real current data) ====================
  function renderAlerts(weather) {
    const alerts = [];
    const c = weather.current;

    if (c.weatherGroup === "fog") {
      alerts.push({
        title: "Dense Fog Advisory",
        description:
          "Low visibility expected. Drive carefully and allow extra travel time.",
        severity: "moderate",
      });
    }
    if (c.weatherGroup === "thunder") {
      alerts.push({
        title: "Thunderstorm Warning",
        description:
          "Lightning activity reported in the area. Seek sturdy shelter and avoid open spaces.",
        severity: "high",
      });
    }
    if (c.windSpeed >= 50) {
      alerts.push({
        title: "High Wind Advisory",
        description: `Sustained winds near ${Math.round(c.windSpeed)} km/h. Secure loose outdoor objects.`,
        severity: "moderate",
      });
    }
    if (c.temperature >= 38) {
      alerts.push({
        title: "Extreme Heat Advisory",
        description:
          "Very high temperatures expected. Stay hydrated and limit outdoor exposure.",
        severity: "high",
      });
    }
    if (c.temperature <= -5) {
      alerts.push({
        title: "Extreme Cold Advisory",
        description:
          "Dangerously low temperatures expected. Limit time outdoors and dress warmly.",
        severity: "high",
      });
    }
    if (
      (c.weatherGroup === "rain" || c.weatherGroup === "snow") &&
      c.humidity >= 90
    ) {
      alerts.push({
        title: "Heavy Precipitation Advisory",
        description: `${c.weatherLabel} with high humidity. Watch for reduced visibility and slick surfaces.`,
        severity: "moderate",
      });
    }

    const timestamp = new Intl.DateTimeFormat("en-US", {
      day: "numeric",
      month: "short",
      year: "numeric",
      hour: "numeric",
      minute: "2-digit",
      timeZone: weather.timezone || undefined,
    }).format(new Date());

    if (alerts.length === 0) {
      dom.alertCount.hidden = true;
      dom.alertsBody.innerHTML = `
        <div class="alert-ok">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 6L9 17l-5-5"/></svg>
          <span>No severe weather alerts for this location right now.</span>
        </div>`;
      return;
    }

    dom.alertCount.hidden = false;
    dom.alertCount.textContent = String(alerts.length);
    dom.alertsBody.innerHTML = alerts
      .map(
        (alert) => `
        <div class="alert-item">
          <strong>${alert.title}</strong>
          <p>${alert.description}</p>
          <time>${timestamp}</time>
        </div>`,
      )
      .join("");
  }

  // ==================== WEATHER TIP RENDERING ====================
  function renderTip(weather) {
    const tip = Tips.generateTip(weather.current, state.isCelsius);
    dom.tipText.textContent = tip.text;
  }

  // ==================== MAP FUNCTIONS ====================
  function ensureMapInitialized() {
    if (state.mapReady) return;
    const map = MapModule.initMap("leafletMap");
    if (map) {
      state.mapReady = true;
    } else {
      document.getElementById("leafletMap").hidden = true;
      document.getElementById("mapFallback").hidden = false;
    }
  }

  function updateMap(location) {
    if (state.mapReady) {
      MapModule.updateLocation(
        location.latitude,
        location.longitude,
        `<strong>${location.name}</strong>`,
      );
    } else {
      const fallback = document.getElementById("mapFallback");
      fallback.hidden = false;
      fallback.innerHTML = `
        <p><strong>${location.name}</strong></p>
        <p>${location.latitude.toFixed(3)}°, ${location.longitude.toFixed(3)}°</p>
        <p style="font-size:0.8rem;">Map could not be loaded. Showing coordinates instead.</p>`;
    }
  }

  // ==================== SAVED LOCATIONS (FAVORITES) UI ====================
  function renderSavedLocations() {
    const saved = Favorites.readAll();
    dom.savedEmpty.hidden = saved.length > 0;
    dom.savedList.innerHTML = saved
      .map(
        (loc, index) => `
        <li class="saved-item">
          <button type="button" class="select-saved" data-index="${index}">${loc.name}</button>
          <button type="button" class="remove-saved" data-index="${index}" aria-label="Remove ${loc.name}">✕</button>
        </li>`,
      )
      .join("");

    dom.savedList.querySelectorAll(".select-saved").forEach((btn) => {
      btn.addEventListener("click", () => {
        const loc = saved[Number(btn.dataset.index)];
        if (loc) loadLocation(loc);
      });
    });
    dom.savedList.querySelectorAll(".remove-saved").forEach((btn) => {
      btn.addEventListener("click", () => {
        const loc = saved[Number(btn.dataset.index)];
        if (loc) {
          Favorites.remove(loc);
          renderSavedLocations();
          if (state.currentLocation) {
            dom.favoriteBtn.setAttribute(
              "aria-pressed",
              String(Favorites.isSaved(state.currentLocation)),
            );
          }
        }
      });
    });
  }

  dom.favoriteBtn.addEventListener("click", () => {
    if (!state.currentLocation) return;
    Favorites.toggle(state.currentLocation);
    dom.favoriteBtn.setAttribute(
      "aria-pressed",
      String(Favorites.isSaved(state.currentLocation)),
    );
    renderSavedLocations();
    announce(
      Favorites.isSaved(state.currentLocation)
        ? "Location saved."
        : "Location removed from saved list.",
    );
  });

  dom.exploreSaved.addEventListener("click", () => {
    const isHidden = dom.savedPanel.hidden;
    dom.savedPanel.hidden = !isHidden;
    dom.exploreSaved.setAttribute("aria-expanded", String(isHidden));
    if (isHidden)
      dom.savedPanel.scrollIntoView({ behavior: "smooth", block: "nearest" });
  });

  dom.exploreAlerts.addEventListener("click", () => {
    document
      .getElementById("alertsCard")
      .scrollIntoView({ behavior: "smooth", block: "center" });
  });

  document.querySelectorAll(".explore-card[data-target]").forEach((card) => {
    card.addEventListener("click", () => {
      const target = document.getElementById(card.dataset.target);
      if (target) target.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  });

  // ==================== ACCESSIBILITY LIVE REGION ====================
  function announce(message) {
    dom.liveStatus.textContent = message;
  }

  // ==================== CORE: LOAD A LOCATION END TO END ====================
  async function loadLocation(location) {
    setSearchLoading(true);
    hideSearchError();

    try {
      const weather = await WeatherAPI.fetchWeatherForCoordinates(
        location.latitude,
        location.longitude,
      );

      state.currentLocation = location;
      state.currentWeather = weather;

      renderWeatherCard(location, weather);
      renderForecast(weather.forecast);
      renderAlerts(weather);
      renderTip(weather);
      updateMap(location);
      updateBackgroundForLocation(location, weather.current.weatherGroup);

      announce(`Weather updated for ${location.name}.`);
      dom.searchInput.value = "";
      dom.searchClear.hidden = true;
      hideSuggestions();
    } catch (error) {
      showSearchError(
        error.message ||
          "Something went wrong while loading the weather. Please try again.",
        () => loadLocation(location),
      );
      // Keep any previously valid weather data visible — we simply don't overwrite it.
    } finally {
      setSearchLoading(false);
    }
  }

  // ==================== SEARCH UI STATE HELPERS ====================
  function setSearchLoading(isLoading) {
    dom.searchBtn.disabled = isLoading;
    dom.searchBtn.querySelector(".btn-spinner").hidden = !isLoading;
    dom.searchBtn.querySelector(".btn-label").hidden = isLoading;
  }

  function showSearchError(message, retryFn) {
    dom.searchError.hidden = false;
    dom.searchError.innerHTML = "";
    const text = document.createElement("span");
    text.textContent = message + " ";
    dom.searchError.appendChild(text);
    if (retryFn) {
      const retryBtn = document.createElement("button");
      retryBtn.type = "button";
      retryBtn.textContent = "Retry";
      retryBtn.style.cssText =
        "background:none;border:none;text-decoration:underline;color:inherit;cursor:pointer;font:inherit;padding:0;";
      retryBtn.addEventListener("click", retryFn);
      dom.searchError.appendChild(retryBtn);
    }
  }

  function hideSearchError() {
    dom.searchError.hidden = true;
    dom.searchError.innerHTML = "";
  }

  function hideSuggestions() {
    dom.searchSuggestions.hidden = true;
    dom.searchSuggestions.innerHTML = "";
  }

  function renderSuggestions(results) {
    if (!results.length) {
      hideSuggestions();
      return;
    }
    dom.searchSuggestions.hidden = false;
    dom.searchSuggestions.innerHTML = results
      .map((result, index) => {
        const region = [result.admin1, result.country]
          .filter(Boolean)
          .join(", ");
        return `<button type="button" class="suggestion-item" role="option" data-index="${index}">${result.name}<small>${region}</small></button>`;
      })
      .join("");

    dom.searchSuggestions
      .querySelectorAll(".suggestion-item")
      .forEach((btn) => {
        btn.addEventListener("click", () => {
          const location = results[Number(btn.dataset.index)];
          loadLocation(location);
        });
      });
  }

  // ==================== LOCATION SEARCH (debounced live suggestions) ====================
  dom.searchInput.addEventListener("input", () => {
    const value = dom.searchInput.value;
    dom.searchClear.hidden = value.length === 0;

    clearTimeout(state.searchDebounceTimer);
    if (value.trim().length < 2) {
      hideSuggestions();
      return;
    }
    state.searchDebounceTimer = setTimeout(async () => {
      try {
        const results = await LocationService.searchLocations(value);
        renderSuggestions(results);
      } catch (error) {
        hideSuggestions();
      }
    }, 350);
  });

  dom.searchClear.addEventListener("click", () => {
    dom.searchInput.value = "";
    dom.searchClear.hidden = true;
    hideSuggestions();
    hideSearchError();
    dom.searchInput.focus();
  });

  dom.searchForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const query = dom.searchInput.value.trim();
    hideSearchError();

    if (!query) {
      showSearchError("Please enter a city or location name to search.");
      return;
    }

    setSearchLoading(true);
    try {
      const results = await LocationService.searchLocations(query);
      if (!results.length) {
        showSearchError(
          `No locations found for "${query}". Try a different spelling or a nearby larger city.`,
        );
        return;
      }
      hideSuggestions();
      await loadLocation(results[0]);
    } catch (error) {
      showSearchError(error.message || "Search failed. Please try again.", () =>
        dom.searchForm.requestSubmit(),
      );
    } finally {
      setSearchLoading(false);
    }
  });

  document.addEventListener("click", (event) => {
    if (
      !dom.searchForm.contains(event.target) &&
      !dom.searchSuggestions.contains(event.target)
    ) {
      hideSuggestions();
    }
  });

  // ==================== USE MY LOCATION ====================
  dom.useLocationBtn.addEventListener("click", async () => {
    hideSearchError();
    dom.useLocationBtn.disabled = true;
    const originalHTML = dom.useLocationBtn.innerHTML;
    dom.useLocationBtn.innerHTML = "Locating…";

    try {
      const coords = await LocationService.getCurrentPosition();
      const location = await LocationService.reverseGeocode(
        coords.latitude,
        coords.longitude,
      );
      await loadLocation(location);
    } catch (error) {
      showSearchError(error.message || "Could not determine your location.");
    } finally {
      dom.useLocationBtn.disabled = false;
      dom.useLocationBtn.innerHTML = originalHTML;
    }
  });

  // ==================== POPULAR CITIES PANEL ====================
  function renderPopularCities() {
    dom.popularCitiesPanel.innerHTML = LocationService.POPULAR_CITIES.map(
      (city, index) =>
        `<button type="button" data-index="${index}">${city.name}</button>`,
    ).join("");

    dom.popularCitiesPanel.querySelectorAll("button").forEach((btn) => {
      btn.addEventListener("click", () => {
        const city = LocationService.POPULAR_CITIES[Number(btn.dataset.index)];
        loadLocation(city);
        dom.popularCitiesPanel.hidden = true;
        dom.popularCitiesBtn.setAttribute("aria-expanded", "false");
      });
    });
  }

  dom.popularCitiesBtn.addEventListener("click", () => {
    const isHidden = dom.popularCitiesPanel.hidden;
    dom.popularCitiesPanel.hidden = !isHidden;
    dom.popularCitiesBtn.setAttribute("aria-expanded", String(isHidden));
  });

  // ==================== UNIT TOGGLE (°C / °F) ====================
  dom.unitToggle.addEventListener("click", () => {
    state.isCelsius = !state.isCelsius;
    dom.unitToggle
      .querySelector(".unit-c")
      .classList.toggle("active", state.isCelsius);
    dom.unitToggle
      .querySelector(".unit-f")
      .classList.toggle("active", !state.isCelsius);
    if (state.currentLocation && state.currentWeather) {
      renderWeatherCard(state.currentLocation, state.currentWeather);
      renderForecast(state.currentWeather.forecast);
    }
  });

  // ==================== APPLICATION INITIALIZATION ====================
  function init() {
    initTheme();
    updateGreeting();
    setInterval(updateGreeting, 60 * 1000);

    ensureMapInitialized();
    renderPopularCities();
    renderSavedLocations();

    loadLocation(DEFAULT_LOCATION);
  }

  document.addEventListener("DOMContentLoaded", init);
})();
