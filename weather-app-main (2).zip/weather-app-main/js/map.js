/* ====================================================================
   SKYCAST — MAP MODULE
   Thin wrapper around Leaflet + OpenStreetMap tiles. Falls back to a
   text-based location summary if Leaflet failed to load (e.g. offline
   first launch before the CDN script has ever been cached).
   ==================================================================== */

const MapModule = (() => {
  let mapInstance = null;
  let markerInstance = null;

  function isLeafletAvailable() {
    return typeof L !== "undefined";
  }

  function initMap(containerId) {
    if (!isLeafletAvailable()) return null;

    mapInstance = L.map(containerId, {
      zoomControl: true,
      attributionControl: true,
      scrollWheelZoom: false,
    }).setView([20, 0], 2);

    L.tileLayer(
      "https://basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}.png?key=cb1_3obo_1_8edeab12e8cc79ff8bcbac62",
      {
        maxZoom: 50,
        attribution:
          '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> | &copy; <a href="https://carto.com/attributions">CARTO</a>',
      },
    ).addTo(mapInstance);

    return mapInstance;
  }

  function updateLocation(latitude, longitude, label) {
    if (!mapInstance) return false;

    mapInstance.setView([latitude, longitude], 10, { animate: true });

    if (markerInstance) {
      mapInstance.removeLayer(markerInstance);
    }

    markerInstance = L.marker([latitude, longitude]).addTo(mapInstance);
    if (label) {
      markerInstance.bindPopup(label).openPopup();
    }

    // Leaflet needs a nudge to recalc size when its container becomes visible
    // after being hidden (e.g. on initial responsive layout paint).
    setTimeout(() => mapInstance && mapInstance.invalidateSize(), 200);
    return true;
  }

  return { initMap, updateLocation, isLeafletAvailable };
})();
