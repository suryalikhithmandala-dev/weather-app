/* ====================================================================
   SKYCAST — WEATHER API MODULE
   Talks to the free, key-less Open-Meteo forecast API.
   Docs: https://open-meteo.com/en/docs
   ==================================================================== */

// ==================== API CONFIGURATION ====================
const WeatherAPI = (() => {
  const FORECAST_ENDPOINT = "https://api.open-meteo.com/v1/forecast";
  const REQUEST_TIMEOUT_MS = 12000;

  // WMO Weather interpretation codes -> { label, group, isPrecip }
  // group is used to pick icons / background themes.
  const WMO_CODE_MAP = {
    0: { label: "Clear Sky", group: "clear" },
    1: { label: "Mainly Clear", group: "clear" },
    2: { label: "Partly Cloudy", group: "cloudy" },
    3: { label: "Overcast", group: "overcast" },
    45: { label: "Fog", group: "fog" },
    48: { label: "Depositing Rime Fog", group: "fog" },
    51: { label: "Light Drizzle", group: "rain" },
    53: { label: "Drizzle", group: "rain" },
    55: { label: "Dense Drizzle", group: "rain" },
    56: { label: "Freezing Drizzle", group: "rain" },
    57: { label: "Dense Freezing Drizzle", group: "rain" },
    61: { label: "Light Rain", group: "rain" },
    63: { label: "Rain", group: "rain" },
    65: { label: "Heavy Rain", group: "rain" },
    66: { label: "Freezing Rain", group: "rain" },
    67: { label: "Heavy Freezing Rain", group: "rain" },
    71: { label: "Light Snow", group: "snow" },
    73: { label: "Snow", group: "snow" },
    75: { label: "Heavy Snow", group: "snow" },
    77: { label: "Snow Grains", group: "snow" },
    80: { label: "Light Rain Showers", group: "rain" },
    81: { label: "Rain Showers", group: "rain" },
    82: { label: "Violent Rain Showers", group: "rain" },
    85: { label: "Light Snow Showers", group: "snow" },
    86: { label: "Heavy Snow Showers", group: "snow" },
    95: { label: "Thunderstorm", group: "thunder" },
    96: { label: "Thunderstorm w/ Hail", group: "thunder" },
    99: { label: "Severe Thunderstorm w/ Hail", group: "thunder" },
  };

  function describeWeatherCode(code) {
    return WMO_CODE_MAP[code] || { label: "Unknown", group: "clear" };
  }

  function degreesToCompass(degrees) {
    const directions = [
      "N",
      "NNE",
      "NE",
      "ENE",
      "E",
      "ESE",
      "SE",
      "SSE",
      "S",
      "SSW",
      "SW",
      "WSW",
      "W",
      "WNW",
      "NW",
      "NNW",
    ];
    const index = Math.round(degrees / 22.5) % 16;
    return directions[index];
  }

  // Small helper: fetch with timeout so a slow network never hangs the UI forever.
  async function fetchWithTimeout(url, timeoutMs) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const response = await fetch(url, { signal: controller.signal });
      return response;
    } finally {
      clearTimeout(timer);
    }
  }

  // ==================== CURRENT + FORECAST FETCH ====================
  async function fetchWeatherForCoordinates(latitude, longitude) {
    const params = new URLSearchParams({
      latitude: latitude.toFixed(4),
      longitude: longitude.toFixed(4),
      current: [
        "temperature_2m",
        "relative_humidity_2m",
        "apparent_temperature",
        "wind_speed_10m",
        "wind_direction_10m",
        "weather_code",
        "surface_pressure",
        "is_day",
      ].join(","),
      daily: ["weather_code", "temperature_2m_max", "temperature_2m_min"].join(
        ",",
      ),
      timezone: "auto",
      forecast_days: 6,
    });

    let response;
    try {
      response = await fetchWithTimeout(
        `${FORECAST_ENDPOINT}?${params.toString()}`,
        REQUEST_TIMEOUT_MS,
      );
    } catch (error) {
      if (error.name === "AbortError") {
        throw new Error(
          "The weather service took too long to respond. Please check your connection and try again.",
        );
      }
      throw new Error(
        "Could not reach the weather service. Please check your internet connection.",
      );
    }

    if (!response.ok) {
      throw new Error(
        `Weather service returned an error (status ${response.status}). Please try again shortly.`,
      );
    }

    const data = await response.json();

    if (!data || !data.current || !data.daily) {
      throw new Error(
        "The weather service returned incomplete data for this location.",
      );
    }

    return normalizeWeatherPayload(data);
  }

  function normalizeWeatherPayload(raw) {
    const current = raw.current;
    const daily = raw.daily;
    const codeInfo = describeWeatherCode(current.weather_code);

    const forecastDays = daily.time.map((isoDate, index) => {
      const dayCodeInfo = describeWeatherCode(daily.weather_code[index]);
      return {
        date: isoDate,
        weatherCode: daily.weather_code[index],
        group: dayCodeInfo.group,
        label: dayCodeInfo.label,
        tempMax: daily.temperature_2m_max[index],
        tempMin: daily.temperature_2m_min[index],
      };
    });

    return {
      timezone: raw.timezone,
      current: {
        temperature: current.temperature_2m,
        feelsLike: current.apparent_temperature,
        humidity: current.relative_humidity_2m,
        windSpeed: current.wind_speed_10m,
        windDirectionDegrees: current.wind_direction_10m,
        windDirectionLabel: degreesToCompass(current.wind_direction_10m),
        pressure: current.surface_pressure,
        weatherCode: current.weather_code,
        weatherGroup: codeInfo.group,
        weatherLabel: codeInfo.label,
        isDay: current.is_day === 1,
        time: current.time,
      },
      // Skip index 0 (today) is NOT skipped here — caller decides how many days to render.
      forecast: forecastDays,
    };
  }

  // ==================== UNIT CONVERSION HELPERS ====================
  function celsiusToFahrenheit(celsius) {
    return (celsius * 9) / 5 + 32;
  }

  function kmhToMph(kmh) {
    return kmh * 0.621371;
  }

  return {
    fetchWeatherForCoordinates,
    describeWeatherCode,
    degreesToCompass,
    celsiusToFahrenheit,
    kmhToMph,
  };
})();
