(() => {
  "use strict";

  const SESSION_KEY = "skycast.session";
  const USERS_KEY = "skycast.users";
  const DEMO_ACCOUNTS = {
    user: {
      email: "user@skycast.app",
      password: "skycast2026",
      name: "SkyCast User",
    },
    admin: {
      email: "admin@skycast.app",
      password: "skycast2026",
      name: "SkyCast Admin",
    },
  };

  function getSession() {
    try {
      return JSON.parse(localStorage.getItem(SESSION_KEY) || "null");
    } catch (error) {
      return null;
    }
  }

  function getUsers() {
    try {
      const users = JSON.parse(localStorage.getItem(USERS_KEY) || "[]");
      return Array.isArray(users) ? users : [];
    } catch (error) {
      return [];
    }
  }

  function findUser(email) {
    const normalizedEmail = email.trim().toLowerCase();
    const registeredUser = getUsers().find((user) => user.email === normalizedEmail);
    if (registeredUser) return registeredUser;
    if (normalizedEmail === DEMO_ACCOUNTS.user.email) return DEMO_ACCOUNTS.user;
    return null;
  }

  function saveUser(name, email, password) {
    const users = getUsers();
    users.push({ name, email, password });
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
  }

  function setSession(role, account) {
    localStorage.setItem(
      SESSION_KEY,
      JSON.stringify({ role, email: account.email, name: account.name }),
    );
  }

  function clearSession() {
    localStorage.removeItem(SESSION_KEY);
  }

  function redirectToLogin(role) {
    window.location.href = role === "admin" ? "admin-login.html" : "login.html";
  }

  function showWeatherApp() {
    const authGate = document.getElementById("authGate");
    const weatherApp = document.getElementById("weatherApp");
    if (authGate) authGate.hidden = true;
    if (weatherApp) weatherApp.classList.add("is-authenticated");
  }

  function showGatePanel(panelName) {
    document.querySelectorAll("[data-auth-panel]").forEach((panel) => {
      panel.hidden = panel.dataset.authPanel !== panelName;
    });
    document.querySelectorAll("[data-auth-view]").forEach((button) => {
      const isActive = button.dataset.authView === panelName;
      button.classList.toggle("is-active", isActive);
      button.setAttribute("aria-selected", String(isActive));
    });
  }

  const authGate = document.getElementById("authGate");
  if (authGate) {
    const session = getSession();
    if (session?.role === "user") {
      showWeatherApp();
    }

    document.querySelectorAll("[data-auth-view]").forEach((button) => {
      button.addEventListener("click", () => showGatePanel(button.dataset.authView));
    });

    const loginForm = document.getElementById("userLoginForm");
    const loginError = document.getElementById("gateLoginError");
    loginForm.addEventListener("submit", (event) => {
      event.preventDefault();
      const email = document.getElementById("gateLoginEmail").value.trim().toLowerCase();
      const password = document.getElementById("gateLoginPassword").value;
      const user = findUser(email);
      const isValid = user && user.password === password;
      loginError.hidden = Boolean(isValid);
      if (!isValid) {
        loginError.textContent = "That email or password does not match an account.";
        return;
      }
      setSession("user", user);
      showWeatherApp();
    });

    const signupForm = document.getElementById("userSignupForm");
    const signupError = document.getElementById("gateSignupError");
    signupForm.addEventListener("submit", (event) => {
      event.preventDefault();
      const name = document.getElementById("gateSignupName").value.trim();
      const email = document.getElementById("gateSignupEmail").value.trim().toLowerCase();
      const password = document.getElementById("gateSignupPassword").value;
      const emailExists = findUser(email);
      let error = "";
      if (name.length < 2) error = "Please enter your name.";
      else if (!email.includes("@")) error = "Please enter a valid email address.";
      else if (emailExists) error = "An account with this email already exists.";
      else if (password.length < 6) error = "Your password must be at least 6 characters.";
      signupError.hidden = !error;
      signupError.textContent = error;
      if (error) return;
      saveUser(name, email, password);
      document.getElementById("gateLoginEmail").value = email;
      document.getElementById("gateLoginPassword").value = "";
      loginError.textContent = "Account created. Please sign in to continue.";
      loginError.hidden = false;
      showGatePanel("login");
    });
  }

  const userLogout = document.getElementById("userLogout");
  if (userLogout) {
    userLogout.addEventListener("click", () => {
      clearSession();
      const authGate = document.getElementById("authGate");
      const weatherApp = document.getElementById("weatherApp");
      if (authGate) authGate.hidden = false;
      if (weatherApp) weatherApp.classList.remove("is-authenticated");
      showGatePanel("login");
      document.getElementById("gateLoginPassword").value = "";
    });
  }

  const loginForm = document.getElementById("loginForm");
  if (loginForm) {
    const role = document.body.dataset.authRole || "user";
    const errorMessage = document.getElementById("loginError");
    const emailInput = document.getElementById("email");
    const passwordInput = document.getElementById("password");

    if (getSession()?.role === role) {
      window.location.href = role === "admin" ? "admin.html" : "index.html";
      return;
    }

    loginForm.addEventListener("submit", (event) => {
      event.preventDefault();
      const email = emailInput.value.trim().toLowerCase();
      const password = passwordInput.value;
      const account = role === "user" ? findUser(email) : DEMO_ACCOUNTS[role];
      const isValid = account && account.password === password;

      errorMessage.hidden = isValid;
      if (!isValid) {
        errorMessage.textContent =
          "That email or password does not match the demo account.";
        passwordInput.focus();
        return;
      }

      setSession(role, account);
      window.location.href = role === "admin" ? "admin.html" : "index.html";
    });
  }

  const adminPage = document.getElementById("adminPage");
  if (adminPage) {
    const session = getSession();
    if (!session || session.role !== "admin") {
      redirectToLogin("admin");
      return;
    }

    document.querySelectorAll("[data-admin-name]").forEach((element) => {
      element.textContent = session.name;
    });

    const logoutButton = document.getElementById("logoutButton");
    logoutButton.addEventListener("click", () => {
      clearSession();
      redirectToLogin("admin");
    });
  }
})();
