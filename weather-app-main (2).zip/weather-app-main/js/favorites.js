/* ====================================================================
   SKYCAST — SAVED LOCATIONS (FAVORITES) MODULE
   Persists a small list of favorite locations in localStorage.
   No login, no server, no unnecessary personal data.
   ==================================================================== */

const Favorites = (() => {
  const STORAGE_KEY = "skycast.savedLocations.v1";
  const MAX_SAVED = 12;

  function readAll() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      const parsed = raw ? JSON.parse(raw) : [];
      return Array.isArray(parsed) ? parsed : [];
    } catch (error) {
      return [];
    }
  }

  function writeAll(locations) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(locations));
      return true;
    } catch (error) {
      // localStorage may be unavailable (private browsing, quota, etc). Fail silently.
      return false;
    }
  }

  function makeKey(location) {
    return `${location.name}|${location.latitude.toFixed(2)}|${location.longitude.toFixed(2)}`;
  }

  function isSaved(location) {
    const key = makeKey(location);
    return readAll().some((item) => makeKey(item) === key);
  }

  function add(location) {
    const all = readAll();
    const key = makeKey(location);
    if (all.some((item) => makeKey(item) === key)) return all;

    const trimmed = {
      name: location.name,
      country: location.country || "",
      admin1: location.admin1 || "",
      latitude: location.latitude,
      longitude: location.longitude,
    };

    const updated = [trimmed, ...all].slice(0, MAX_SAVED);
    writeAll(updated);
    return updated;
  }

  function remove(location) {
    const key = makeKey(location);
    const updated = readAll().filter((item) => makeKey(item) !== key);
    writeAll(updated);
    return updated;
  }

  function toggle(location) {
    return isSaved(location) ? remove(location) : add(location);
  }

  return { readAll, add, remove, toggle, isSaved };
})();
