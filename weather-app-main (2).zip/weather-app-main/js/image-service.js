/* ====================================================================
   SKYCAST — BACKGROUND IMAGE MODULE
   Resolves an atmospheric background image for a searched location
   using a graceful fallback chain that never leaves the UI broken:
     1. Wikipedia page image for the city (key-less REST API)
     2. Wikipedia page image for the country
     3. A weather-condition based gradient theme
     4. The default gradient background
   ==================================================================== */

const ImageService = (() => {
  const WIKI_SUMMARY_ENDPOINT =
    "https://en.wikipedia.org/api/rest_v1/page/summary/";
  const REQUEST_TIMEOUT_MS = 8000;

  // Gradient themes used whenever a real photo can't be resolved.
  // Chosen to echo the dusk-sky / mountain aesthetic of the reference design.
  const WEATHER_GRADIENTS = {
    clear: ["#1c3a5e", "#e0964a"],
    cloudy: ["#2b3c52", "#7d8ea3"],
    overcast: ["#28313f", "#4c5a6b"],
    fog: ["#3a4652", "#8a97a3"],
    rain: ["#1b2735", "#3c5064"],
    snow: ["#3b4a5a", "#c9d6e0"],
    thunder: ["#161c26", "#4a3a5c"],
    default: ["#0b1a2b", "#1c3350"],
  };

  async function fetchWithTimeout(url, timeoutMs) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      return await fetch(url, {
        signal: controller.signal,
        headers: { Accept: "application/json" },
      });
    } finally {
      clearTimeout(timer);
    }
  }

  async function fetchWikipediaImage(pageTitle) {
    if (!pageTitle) return null;
    try {
      const response = await fetchWithTimeout(
        `${WIKI_SUMMARY_ENDPOINT}${encodeURIComponent(pageTitle)}`,
        REQUEST_TIMEOUT_MS,
      );
      if (!response.ok) return null;
      const data = await response.json();
      const image = data.originalimage || data.thumbnail;
      if (image && image.source) {
        return image.source;
      }
      return null;
    } catch (error) {
      return null;
    }
  }

  /**
   * Resolves the best available background for a location.
   * Returns { type: 'photo', url } or { type: 'gradient', colors: [a, b] }
   */
  async function resolveLocationBackground({
    cityName,
    admin1,
    country,
    weatherGroup,
  }) {
    // Attempt 1: the city itself (most specific).
    let imageUrl = await fetchWikipediaImage(cityName);

    // Attempt 2: "City, Country" — helps disambiguate common city names.
    if (!imageUrl && country) {
      imageUrl = await fetchWikipediaImage(`${cityName}, ${country}`);
    }

    // Attempt 3: the region/state.
    if (!imageUrl && admin1) {
      imageUrl = await fetchWikipediaImage(admin1);
    }

    // Attempt 4: the country as a whole.
    if (!imageUrl && country) {
      imageUrl = await fetchWikipediaImage(country);
    }

    if (imageUrl) {
      return { type: "photo", url: imageUrl };
    }

    // Attempt 5: weather-condition gradient theme.
    const colors = WEATHER_GRADIENTS[weatherGroup] || WEATHER_GRADIENTS.default;
    return { type: "gradient", colors };
  }

  return { resolveLocationBackground, WEATHER_GRADIENTS };
})();
