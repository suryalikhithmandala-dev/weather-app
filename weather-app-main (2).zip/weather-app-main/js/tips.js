/* ====================================================================
   SKYCAST — WEATHER TIPS MODULE
   Simple, transparent rule-based tips generated from real current
   weather values. No external AI calls — plain JavaScript logic.
   ==================================================================== */

const Tips = (() => {
  /**
   * @param {Object} current - normalized current weather object
   * @param {boolean} isCelsius
   * @returns {{ text: string }}
   */
  function generateTip(current, isCelsius) {
    const tempC = current.temperature;
    const feelsLikeC = current.feelsLike;
    const windKmh = current.windSpeed;
    const group = current.weatherGroup;

    if (group === "thunder") {
      return {
        text: "Thunderstorms are active in the area. Stay indoors and avoid open fields or tall isolated trees.",
      };
    }
    if (group === "fog") {
      return {
        text: "Visibility is reduced by fog. Drive carefully, use low beams, and allow extra travel time.",
      };
    }
    if (group === "snow") {
      return {
        text: "Snow is falling. Wear warm, waterproof layers and watch for slippery surfaces underfoot.",
      };
    }
    if (group === "rain") {
      return {
        text: "Rain is expected. Carry an umbrella and consider waterproof footwear before heading out.",
      };
    }
    if (windKmh >= 40) {
      return {
        text: "Winds are strong today. Take care near exposed areas, trees, and loose outdoor items.",
      };
    }
    if (feelsLikeC <= 5) {
      return {
        text: "It feels quite cold. Consider wearing a warm jacket, gloves, and a hat when you head out.",
      };
    }
    if (feelsLikeC <= 15) {
      return {
        text: "It's a bit chilly today. Consider wearing a light jacket when you head out.",
      };
    }
    if (feelsLikeC >= 34) {
      return {
        text: "It feels very hot. Stay hydrated, seek shade, and avoid prolonged direct sunlight.",
      };
    }
    if (feelsLikeC >= 28) {
      return {
        text: "Warm conditions today. Stay hydrated and wear light, breathable clothing.",
      };
    }
    if (group === "clear") {
      return {
        text: "Clear skies ahead — a great day to spend time outdoors. Don't forget sun protection.",
      };
    }
    return { text: "Conditions look mild and comfortable. Enjoy your day." };
  }

  return { generateTip };
})();
