/* ====================================================================
   SKYCAST — ELECTRON PRELOAD SCRIPT
   Runs in an isolated context before the renderer loads. SkyCast's
   front-end does not currently need any privileged Node APIs, so this
   file intentionally exposes nothing — it exists as the designated,
   secure place to add a contextBridge API in the future if needed.
   ==================================================================== */

// Example of how to safely expose a native capability later:
//
// const { contextBridge } = require("electron");
// contextBridge.exposeInMainWorld("skycastNative", {
//   getAppVersion: () => process.env.npm_package_version
// });
